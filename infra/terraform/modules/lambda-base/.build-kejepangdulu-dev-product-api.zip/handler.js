const PRODUCTS = [
  {
    id: "p1",
    name: "Hiragana Dasar",
    price: 1100,
    description: "Basic Hiragana learning package"
  },
  {
    id: "p2",
    name: "Katakana Dasar",
    price: 1200,
    description: "Basic Katakana learning package"
  }
];

const jsonResponse = (statusCode, body) => ({
  statusCode,
  headers: {
    "content-type": "application/json",
    "access-control-allow-origin": "*"
  },
  body: JSON.stringify(body)
});

const handler = async (event) => {
  if (event.routeKey === "GET /api/products") {
    const list = PRODUCTS.map(({ id, name, price }) => ({ id, name, price }));
    return jsonResponse(200, list);
  }

  if (event.routeKey === "GET /api/products/{id}") {
    const productId = event.pathParameters && event.pathParameters.id;
    if (!productId) {
      return jsonResponse(400, { message: "Missing product id" });
    }

    const product = PRODUCTS.find((item) => item.id === productId);
    if (!product) {
      return jsonResponse(404, { message: "Product not found" });
    }

    return jsonResponse(200, product);
  }

  return jsonResponse(404, { message: "Route not found" });
};

exports.handler = handler;
exports.main = handler;
